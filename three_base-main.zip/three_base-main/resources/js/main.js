import * as THREE from "three";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import dat from "dat.gui";
import { gsap } from "gsap";

const DEBUG = location.search.indexOf("debug") > -1;

const threeProject = (() => {
  let loadingManager,
    scene,
    renderer,
    camera,
    ambientLight,
    directionalLight,
    gltfLoader,
    url,
    model,
    textureLoader,
    requestToRender,
    raf;

  let areaWidth = window.innerWidth;
  let areaHeight = window.innerHeight;

  const setTheManager = () => {
    loadingManager = new THREE.LoadingManager();
    loadingManager.onLoad = () => {};
    loadingManager.onStart = () => {};
    loadingManager.onProgress = (url, itemsLoaded, itemsTotal) => {};
  };

  const setTheScene = () => {
    scene = new THREE.Scene();
  };

  const setTheRenderer = () => {
    renderer = new THREE.WebGLRenderer({
      antialias: true,
    });
    renderer.setClearColor(0x000000);
    renderer.setSize(areaWidth, areaHeight);
    renderer.setPixelRatio(devicePixelRatio);
    renderer.outputEncoding = THREE.sRGBEncoding;
    document.body.appendChild(renderer.domElement);
  };

  const setTheCamera = () => {
    camera = new THREE.PerspectiveCamera(45, areaWidth / areaHeight, 1, 100);
    camera.position.z = 3;
  };

  const setTheLight = () => {
    ambientLight = new THREE.AmbientLight("#fff", 1);
    directionalLight = new THREE.DirectionalLight("#fff", 1);

    scene.add(ambientLight, directionalLight);
  };

  const setTheModel = () => {
    gltfLoader = new GLTFLoader();
    // url = "./";

    // gltfLoader.load(url, (object) => {
    //   model = object;
    //   scene.add(model.scene);
    // });

    let geometry = new THREE.BoxGeometry(1, 1, 1);
    let meterial = new THREE.MeshBasicMaterial({ color: "orange" });
    let mesh = new THREE.Mesh(geometry, meterial);
    scene.add(mesh);
  };

  const setTheTexture = () => {
    textureLoader = new THREE.TextureLoader(loadingManager);
  };

  const setTheRender = () => {
    if (requestToRender) {
      renderer.render(scene, camera);
      requestToRender = false;
    }
    raf = requestAnimationFrame(setTheRender);
  };

  const renderRequest = () => {
    requestToRender = true;
  };

  const resize = () => {
    areaWidth = window.innerWidth;
    areaHeight = window.innerHeight;

    camera.aspect = areaWidth / areaHeight;
    camera.updateProjectionMatrix();

    renderer.setSize(areaWidth, areaHeight);
    renderer.setPixelRatio(devicePixelRatio);

    renderRequest();
  };

  const addEvent = () => {
    window.addEventListener("resize", resize);
  };

  const debugMode = () => {
    if (DEBUG) {
      let gui = new dat.GUI();
      gui.domElement.parentNode.style.zIndex = 100;

      const control = new OrbitControls(camera, renderer.domElement);
      control.addEventListener("change", function () {
        renderRequest();
      });

      scene.add(new THREE.AxesHelper());

      gui &&
        gui
          .add(camera.position, "y", 0, 2, 0.00001)
          .name("camera y")
          .onChange(renderRequest);
    }
  };

  const initialize = () => {
    setTheManager();
    setTheScene();
    setTheRenderer();
    setTheCamera();
    setTheLight();
    setTheModel();
    setTheTexture();
    setTheRender();
    addEvent();
    debugMode();
  };

  return {
    init: initialize,
  };
})();

onload = threeProject.init();
